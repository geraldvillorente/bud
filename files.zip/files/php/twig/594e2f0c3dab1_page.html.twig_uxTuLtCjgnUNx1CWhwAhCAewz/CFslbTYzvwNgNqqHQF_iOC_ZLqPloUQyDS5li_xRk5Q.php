<?php

/* themes/bud/templates/layout/page.html.twig */
class __TwigTemplate_f4d5442b1b8567fa1ae2d561932ab4576a592c47cb39ecf2f4315ac79d71f7cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 59, "set" => 60);
        $filters = array();
        $functions = array("attach_library" => 48);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('if', 'set'),
                array(),
                array('attach_library')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 47
        echo "
";
        // line 48
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->attachLibrary("bud/layouts"), "html", null, true));
        echo "
<div class=\"layout-center\">

  <header class=\"header\" role=\"banner\">
    ";
        // line 52
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header", array()), "html", null, true));
        echo "
    ";
        // line 53
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "secondary_menu", array()), "html", null, true));
        echo "
  </header>

  <div class=\"layout-3col\">

    ";
        // line 59
        echo "    ";
        if (($this->getAttribute(($context["page"] ?? null), "sidebar_first", array()) && $this->getAttribute(($context["page"] ?? null), "sidebar_second", array()))) {
            // line 60
            echo "      ";
            $context["content_class"] = "layout-3col__right-content";
            // line 61
            echo "      ";
            $context["sidebar_first_class"] = "layout-3col__first-left-sidebar";
            // line 62
            echo "      ";
            $context["sidebar_second_class"] = "layout-3col__second-left-sidebar";
            // line 63
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "sidebar_second", array())) {
            // line 64
            echo "      ";
            $context["content_class"] = "layout-3col__left-content";
            // line 65
            echo "      ";
            $context["sidebar_first_class"] = "";
            // line 66
            echo "      ";
            $context["sidebar_second_class"] = "layout-3col__right-sidebar";
            // line 67
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "sidebar_first", array())) {
            // line 68
            echo "      ";
            $context["content_class"] = "layout-3col__right-content";
            // line 69
            echo "      ";
            $context["sidebar_first_class"] = "layout-3col__left-sidebar";
            // line 70
            echo "      ";
            $context["sidebar_second_class"] = "";
            // line 71
            echo "    ";
        } else {
            // line 72
            echo "      ";
            $context["content_class"] = "layout-3col__full";
            // line 73
            echo "      ";
            $context["sidebar_first_class"] = "";
            // line 74
            echo "      ";
            $context["sidebar_second_class"] = "";
            // line 75
            echo "    ";
        }
        // line 76
        echo "
    ";
        // line 78
        echo "    ";
        if ((($this->getAttribute(($context["page"] ?? null), "footer_first", array()) && $this->getAttribute(($context["page"] ?? null), "footer_second", array())) && $this->getAttribute(($context["page"] ?? null), "footer_third", array()))) {
            // line 79
            echo "      ";
            $context["footer_first_class"] = "layout-3col__col-1";
            // line 80
            echo "      ";
            $context["footer_second_class"] = "layout-3col__col-2";
            // line 81
            echo "      ";
            $context["footer_third_class"] = "layout-3col__col-3";
            // line 82
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "footer_first", array())) {
            // line 83
            echo "      ";
            $context["footer_first_class"] = "layout-3col__col-1";
            // line 84
            echo "      ";
            $context["footer_second_class"] = "";
            // line 85
            echo "      ";
            $context["footer_third_class"] = "";
            // line 86
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "footer_second", array())) {
            // line 87
            echo "      ";
            $context["footer_first_class"] = "";
            // line 88
            echo "      ";
            $context["footer_second_class"] = "layout-3col__col-2";
            // line 89
            echo "      ";
            $context["footer_third_class"] = "";
            // line 90
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "footer_third", array())) {
            // line 91
            echo "      ";
            $context["footer_first_class"] = "";
            // line 92
            echo "      ";
            $context["footer_second_class"] = "";
            // line 93
            echo "      ";
            $context["footer_third_class"] = "layout-3col__col-3";
            // line 94
            echo "    ";
        }
        // line 95
        echo "
    ";
        // line 97
        echo "    ";
        if ((($this->getAttribute(($context["page"] ?? null), "content_first", array()) && $this->getAttribute(($context["page"] ?? null), "content_second", array())) && $this->getAttribute(($context["page"] ?? null), "content_third", array()))) {
            // line 98
            echo "      ";
            $context["content_first_class"] = "layout-3col__col-1";
            // line 99
            echo "      ";
            $context["content_second_class"] = "layout-3col__col-2";
            // line 100
            echo "      ";
            $context["content_third_class"] = "layout-3col__col-3";
            // line 101
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "content_first", array())) {
            // line 102
            echo "      ";
            $context["content_first_class"] = "layout-3col__col-1";
            // line 103
            echo "      ";
            $context["content_second_class"] = "";
            // line 104
            echo "      ";
            $context["content_third_class"] = "";
            // line 105
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "content_second", array())) {
            // line 106
            echo "      ";
            $context["content_first_class"] = "";
            // line 107
            echo "      ";
            $context["content_second_class"] = "layout-3col__col-2";
            // line 108
            echo "      ";
            $context["content_third_class"] = "";
            // line 109
            echo "    ";
        } elseif ($this->getAttribute(($context["page"] ?? null), "content_third", array())) {
            // line 110
            echo "      ";
            $context["content_first_class"] = "";
            // line 111
            echo "      ";
            $context["content_second_class"] = "";
            // line 112
            echo "      ";
            $context["content_third_class"] = "layout-3col__col-3";
            // line 113
            echo "    ";
        }
        // line 114
        echo "
    <div class=\"layout-3col__full\">
      ";
        // line 116
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "primary_menu", array()), "html", null, true));
        echo "
    </div>

    <main class=\"";
        // line 119
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["content_class"] ?? null), "html", null, true));
        echo "\" role=\"main\">

      ";
        // line 121
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
        echo "
      ";
        // line 122
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "breadcrumb", array()), "html", null, true));
        echo "
      <a href=\"#skip-link\" class=\"visually-hidden visually-hidden--focusable\" id=\"main-content\">Back to top</a>";
        // line 124
        echo "      ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "title", array()), "html", null, true));
        echo "
      ";
        // line 125
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "help", array()), "html", null, true));
        echo "
      ";
        // line 126
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
        echo "

    </main>

    ";
        // line 130
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_first", array())) {
            // line 131
            echo "      <aside class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["sidebar_first_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
        ";
            // line 132
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "sidebar_first", array()), "html", null, true));
            echo "
      </aside>
    ";
        }
        // line 135
        echo "
    ";
        // line 136
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_second", array())) {
            // line 137
            echo "      <aside class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["sidebar_second_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
        ";
            // line 138
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "sidebar_second", array()), "html", null, true));
            echo "
      </aside>
    ";
        }
        // line 141
        echo "
    ";
        // line 142
        if ($this->getAttribute(($context["page"] ?? null), "content_first", array())) {
            // line 143
            echo "      <div class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["content_first_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
        ";
            // line 144
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content_first", array()), "html", null, true));
            echo "
      </div>
    ";
        }
        // line 147
        echo "
    ";
        // line 148
        if ($this->getAttribute(($context["page"] ?? null), "content_second", array())) {
            // line 149
            echo "      <div class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["content_second_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
        ";
            // line 150
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content_second", array()), "html", null, true));
            echo "
      </div>
    ";
        }
        // line 153
        echo "
    ";
        // line 154
        if ($this->getAttribute(($context["page"] ?? null), "content_third", array())) {
            // line 155
            echo "      <div class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["content_third_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
        ";
            // line 156
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content_third", array()), "html", null, true));
            echo "
      </div>
    ";
        }
        // line 159
        echo "
    <div class=\"layout-3col__full\">
      ";
        // line 161
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content_bottom", array()), "html", null, true));
        echo "
    </div>
  </div>

  ";
        // line 165
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer", array()), "html", null, true));
        echo "

  ";
        // line 167
        if ($this->getAttribute(($context["page"] ?? null), "footer_first", array())) {
            // line 168
            echo "    <div class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["footer_first_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
      ";
            // line 169
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_first", array()), "html", null, true));
            echo "
    </div>
  ";
        }
        // line 172
        echo "
  ";
        // line 173
        if ($this->getAttribute(($context["page"] ?? null), "footer_second", array())) {
            // line 174
            echo "    <div class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["footer_second_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
      ";
            // line 175
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_second", array()), "html", null, true));
            echo "
    </div>
  ";
        }
        // line 178
        echo "
  ";
        // line 179
        if ($this->getAttribute(($context["page"] ?? null), "footer_third", array())) {
            // line 180
            echo "    <div class=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["footer_third_class"] ?? null), "html", null, true));
            echo "\" role=\"complementary\">
      ";
            // line 181
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_third", array()), "html", null, true));
            echo "
    </div>
  ";
        }
        // line 184
        echo "</div>";
        // line 185
        echo "
<div class=\"layout-3col__full\">
  ";
        // line 187
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "bottom", array()), "html", null, true));
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "themes/bud/templates/layout/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  407 => 187,  403 => 185,  401 => 184,  395 => 181,  390 => 180,  388 => 179,  385 => 178,  379 => 175,  374 => 174,  372 => 173,  369 => 172,  363 => 169,  358 => 168,  356 => 167,  351 => 165,  344 => 161,  340 => 159,  334 => 156,  329 => 155,  327 => 154,  324 => 153,  318 => 150,  313 => 149,  311 => 148,  308 => 147,  302 => 144,  297 => 143,  295 => 142,  292 => 141,  286 => 138,  281 => 137,  279 => 136,  276 => 135,  270 => 132,  265 => 131,  263 => 130,  256 => 126,  252 => 125,  247 => 124,  243 => 122,  239 => 121,  234 => 119,  228 => 116,  224 => 114,  221 => 113,  218 => 112,  215 => 111,  212 => 110,  209 => 109,  206 => 108,  203 => 107,  200 => 106,  197 => 105,  194 => 104,  191 => 103,  188 => 102,  185 => 101,  182 => 100,  179 => 99,  176 => 98,  173 => 97,  170 => 95,  167 => 94,  164 => 93,  161 => 92,  158 => 91,  155 => 90,  152 => 89,  149 => 88,  146 => 87,  143 => 86,  140 => 85,  137 => 84,  134 => 83,  131 => 82,  128 => 81,  125 => 80,  122 => 79,  119 => 78,  116 => 76,  113 => 75,  110 => 74,  107 => 73,  104 => 72,  101 => 71,  98 => 70,  95 => 69,  92 => 68,  89 => 67,  86 => 66,  83 => 65,  80 => 64,  77 => 63,  74 => 62,  71 => 61,  68 => 60,  65 => 59,  57 => 53,  53 => 52,  46 => 48,  43 => 47,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
/**
 * @file
 * Theme override to display a single page.
 *
 * The doctype, html, head and body tags are not in this template. Instead they
 * can be found in the html.html.twig template in this directory.
 *
 * Available variables:
 *
 * General utility variables:
 * - base_path: The base URL path of the Drupal installation. Will usually be
 *   \"/\" unless you have installed Drupal in a sub-directory.
 * - is_front: A flag indicating if the current page is the front page.
 * - logged_in: A flag indicating if the user is registered and signed in.
 * - is_admin: A flag indicating if the user has permission to access
 *   administration pages.
 *
 * Site identity:
 * - front_page: The URL of the front page. Use this instead of base_path when
 *   linking to the front page. This includes the language domain or prefix.
 *
 * Page content (in order of occurrence in the default page.html.twig):
 * - node: Fully loaded node, if there is an automatically-loaded node
 *   associated with the page and the node ID is the second argument in the
 *   page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - page.header: Items for the header region.
 * - page.primary_menu: Items for the primary menu region.
 * - page.secondary_menu: Items for the secondary menu region.
 * - page.highlighted: Items for the highlighted content region.
 * - page.breadcrumb: Items for the breadcrumb region.
 * - page.title: Items for the title region.
 * - page.help: Dynamic help text, mostly for admin pages.
 * - page.content: The main content of the current page.
 * - page.sidebar_first: Items for the first sidebar.
 * - page.sidebar_second: Items for the second sidebar.
 * - page.footer: Items for the footer region.
 * - page.bottom: Items for the extreme bottom of the page.
 *
 * @see template_preprocess_page()
 * @see html.html.twig
 */
#}

{{ attach_library('bud/layouts') }}
<div class=\"layout-center\">

  <header class=\"header\" role=\"banner\">
    {{ page.header }}
    {{ page.secondary_menu }}
  </header>

  <div class=\"layout-3col\">

    {# Decide on layout classes by checking if sidebars have content. #}
    {% if page.sidebar_first and page.sidebar_second %}
      {% set content_class        = 'layout-3col__right-content' %}
      {% set sidebar_first_class  = 'layout-3col__first-left-sidebar' %}
      {% set sidebar_second_class = 'layout-3col__second-left-sidebar' %}
    {% elseif (page.sidebar_second) %}
      {% set content_class        = 'layout-3col__left-content' %}
      {% set sidebar_first_class  = '' %}
      {% set sidebar_second_class = 'layout-3col__right-sidebar' %}
    {% elseif (page.sidebar_first) %}
      {% set content_class        = 'layout-3col__right-content' %}
      {% set sidebar_first_class  = 'layout-3col__left-sidebar' %}
      {% set sidebar_second_class = '' %}
    {% else %}
      {% set content_class        = 'layout-3col__full' %}
      {% set sidebar_first_class  = '' %}
      {% set sidebar_second_class = '' %}
    {% endif %}

    {# Decide on layout classes by checking if footer have content. #}
    {% if page.footer_first and page.footer_second and page.footer_third %}
      {% set footer_first_class  = 'layout-3col__col-1' %}
      {% set footer_second_class = 'layout-3col__col-2' %}
      {% set footer_third_class  = 'layout-3col__col-3' %}
    {% elseif (page.footer_first) %}
      {% set footer_first_class  = 'layout-3col__col-1' %}
      {% set footer_second_class = '' %}
      {% set footer_third_class  = '' %}
    {% elseif (page.footer_second) %}
      {% set footer_first_class  = '' %}
      {% set footer_second_class = 'layout-3col__col-2' %}
      {% set footer_third_class  = '' %}
    {% elseif (page.footer_third) %}
      {% set footer_first_class  = '' %}
      {% set footer_second_class = '' %}
      {% set footer_third_class  = 'layout-3col__col-3' %}
    {% endif %}

    {# Decide on layout classes by checking if content three have content. #}
    {% if page.content_first and page.content_second and page.content_third %}
      {% set content_first_class  = 'layout-3col__col-1' %}
      {% set content_second_class = 'layout-3col__col-2' %}
      {% set content_third_class  = 'layout-3col__col-3' %}
    {% elseif (page.content_first) %}
      {% set content_first_class  = 'layout-3col__col-1' %}
      {% set content_second_class = '' %}
      {% set content_third_class  = '' %}
    {% elseif (page.content_second) %}
      {% set content_first_class  = '' %}
      {% set content_second_class = 'layout-3col__col-2' %}
      {% set content_third_class  = '' %}
    {% elseif (page.content_third) %}
      {% set content_first_class  = '' %}
      {% set content_second_class = '' %}
      {% set content_third_class  = 'layout-3col__col-3' %}
    {% endif %}

    <div class=\"layout-3col__full\">
      {{ page.primary_menu }}
    </div>

    <main class=\"{{ content_class }}\" role=\"main\">

      {{ page.highlighted }}
      {{ page.breadcrumb }}
      <a href=\"#skip-link\" class=\"visually-hidden visually-hidden--focusable\" id=\"main-content\">Back to top</a>{# link target is in html.html.twig #}
      {{ page.title }}
      {{ page.help }}
      {{ page.content }}

    </main>

    {% if page.sidebar_first %}
      <aside class=\"{{ sidebar_first_class }}\" role=\"complementary\">
        {{ page.sidebar_first }}
      </aside>
    {% endif %}

    {% if page.sidebar_second %}
      <aside class=\"{{ sidebar_second_class }}\" role=\"complementary\">
        {{ page.sidebar_second }}
      </aside>
    {% endif %}

    {% if page.content_first %}
      <div class=\"{{ content_first_class }}\" role=\"complementary\">
        {{ page.content_first }}
      </div>
    {% endif %}

    {% if page.content_second %}
      <div class=\"{{ content_second_class }}\" role=\"complementary\">
        {{ page.content_second }}
      </div>
    {% endif %}

    {% if page.content_third %}
      <div class=\"{{ content_third_class }}\" role=\"complementary\">
        {{ page.content_third }}
      </div>
    {% endif %}

    <div class=\"layout-3col__full\">
      {{ page.content_bottom }}
    </div>
  </div>

  {{ page.footer }}

  {% if page.footer_first %}
    <div class=\"{{ footer_first_class }}\" role=\"complementary\">
      {{ page.footer_first }}
    </div>
  {% endif %}

  {% if page.footer_second %}
    <div class=\"{{ footer_second_class }}\" role=\"complementary\">
      {{ page.footer_second }}
    </div>
  {% endif %}

  {% if page.footer_third %}
    <div class=\"{{ footer_third_class }}\" role=\"complementary\">
      {{ page.footer_third }}
    </div>
  {% endif %}
</div>{# /.layout-center #}

<div class=\"layout-3col__full\">
  {{ page.bottom }}
</div>
", "themes/bud/templates/layout/page.html.twig", "/Users/iamroald/Sites/budv2/themes/bud/templates/layout/page.html.twig");
    }
}
